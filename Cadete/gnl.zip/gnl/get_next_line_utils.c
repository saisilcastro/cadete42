/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line_utils.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lde-cast <lde-cast@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/05/04 12:08:36 by lde-cast          #+#    #+#             */
/*   Updated: 2023/06/08 19:44:51 by lde-cast         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"

t_byte	*byte_get(char set)
{
	t_byte	*byte;

	byte = (t_byte *)malloc(sizeof(t_byte));
	byte->symbol = set;
	byte->next = NULL;
	return (byte);
}

void	byte_next_last(t_byte **head, t_byte *new)
{
	t_byte	*update;

	if (!new)
		return ;
	if (!*head)
	{
		*head = new;
		return ;
	}
	update = *head;
	while (update->next)
		update = update->next;
	update->next = new;
}

t_file_of	file_start(int fd)
{
	t_file_of	file;

	file.pos = 0;
	file.read = 0;
	file.len = 0;
	file.fd = fd;
	file.string = NULL;
	while (file.pos < BUFFER_SIZE)
		*(file.buffer + file.pos++) = '\0';
	file.pos = 0;
	return (file);
}
