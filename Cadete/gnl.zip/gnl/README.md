# get_next_line
gnl
