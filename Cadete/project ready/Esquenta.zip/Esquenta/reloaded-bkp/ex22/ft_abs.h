#ifndef ABSOLUTE_H
#define ABSOLUTE_H

#define ABS(Value)(Value < 0 ? -Value : Value)

#endif // ABSOLUTE_H