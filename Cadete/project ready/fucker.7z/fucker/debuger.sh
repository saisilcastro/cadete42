name=./$1
valgrind --leak-check=full $name