/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lde-cast <lde-cast@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/05/04 11:45:10 by lde-cast          #+#    #+#             */
/*   Updated: 2023/05/06 13:20:38 by lde-cast         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"
#include <stdio.h>

int	main(void)
{
	int	fd[2];

	fd[0] = open("main.c", O_RDONLY);
	fd[1] = open("get_next_line.c", O_RDONLY);
	get_next_line(fd[0]);
	get_next_line(fd[1]);
	return (0);
}

void	file_test(int fd)
{
	int		i;
	char	*line[100];

	i = 0;
	while (i < 41)
	{
		line[i] = get_next_line(fd);
		if (line[i])
			printf("%i %s\n", i + 1, line[i]);
		i++;
	}
	close(fd);
	i = 0;
	while (i < 41)
	{
		if (line[i])
			free(line[i]);
		i++;
	}
}
