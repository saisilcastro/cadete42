/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lde-cast <lde-cast@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/05/06 11:32:04 by lde-cast          #+#    #+#             */
/*   Updated: 2023/05/06 13:56:21 by lde-cast         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"
#include <unistd.h>
#include <stdio.h>

static ssize_t	get_file_content(int fd, char **update, int done);
char			*get_line(char *buffer, int max);

char	*get_next_line(int fd)
{
	char		*buffer;

	get_file_content(fd, &buffer, 0);
	return (NULL);
}

static ssize_t	get_file_content(int fd, char **update, int done)
{
	char		buffer[BUFFER_SIZE];
	static int	file;
	static int	file_list[FD_SETSIZE];
	ssize_t		i;

	i = file;
	while (i--)
	{
		if (file_list[i] == 0 || file_list[i] == fd)
			break ;
	}
	if (i <= 0)
	{
		file = 0;
		i = 1;
	}
	if (file_list[i] == fd && done)
		file_list[i] = 0;
	file_list[file] = fd;
	if (!done)
	{
		i = read(file_list[file], buffer, BUFFER_SIZE);
		*update = &buffer[0];
	}
	return (i);
}

char	*get_line(char *buffer, int max)
{
	static int	pos = 0;
	int			len;
	int			begin;
	char		*line;

	line = NULL;
	len = -1;
	begin = 0;
	while (pos < max && ++len > -1)
	{
		if (*(buffer + pos) == '\n')
		{
			pos++;
			break ;
		}
		pos++;
	}
	if (pos == max)
	{
		pos = 0;
		return (NULL);
	}
	begin = (pos - len - 1);
	printf("\n%i %i %i\n", pos, begin, begin + len);
	line = (char *)malloc((len + 1) * sizeof(char));
	ft_strlcpy(line, &buffer[begin], len + 1);
	return (line);
}

static char	*get_file_name(int fd)
{
	char		fd_path[255];
	char		filename[255];
	char		*fname;
	int			n;

	sprintf(fd_path, "/proc/self/fd/%i", fd);
	n = readlink(fd_path, filename, 255);
	fname = &filename[0];
	fname[n] = '\0';
	printf("[%s]\n", fname);
}
