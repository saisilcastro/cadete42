/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line_utils.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lde-cast <lde-cast@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/05/04 12:08:36 by lde-cast          #+#    #+#             */
/*   Updated: 2023/05/05 16:41:01 by lde-cast         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"

static void	*ft_memcpy(void *dest, const void *src, size_t n)
{
	unsigned char	*c_src;
	unsigned char	*c_dest;

	c_src = (unsigned char *)src;
	c_dest = (unsigned char *)dest;
	while (n--)
		*c_dest++ = *c_src++;
	return (dest);
}

size_t	ft_strlcpy(char *dest, const char *src, size_t n)
{
	size_t	len;
	size_t	i;

	len = 0;
	while (*(src + len))
		len++;
	if (n > 0)
	{
		i = n - 1;
		if (len < n)
			i = len;
		ft_memcpy(dest, src, i);
		*(dest + i) = '\0';
	}
	return (len);
}
