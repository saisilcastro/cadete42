/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.h                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lde-cast <lde-cast@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/05/04 11:44:53 by lde-cast          #+#    #+#             */
/*   Updated: 2023/05/06 12:45:27 by lde-cast         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef GET_NEXT_LINE_H
# define GET_NEXT_LINE_H

# include <fcntl.h>
# include <stdlib.h>
# include <unistd.h>

# ifndef BUFFER_SIZE
#  define BUFFER_SIZE 0xFFFF
# endif // BUFFER_SIZE

extern void		recall(void);
extern char		*get_next_line(int fd);
extern size_t	ft_strlcpy(char *dest, const char *src, size_t n);

#endif // GET_NEXT_LINE
